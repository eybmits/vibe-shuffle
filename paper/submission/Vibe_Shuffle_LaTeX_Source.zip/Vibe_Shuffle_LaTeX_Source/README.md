# Vibe Shuffle LaTeX source

The archive contains the complete source used to render the accompanying paper.
The main entry point is `main.tex`.

## Build

Install a current TeX Live distribution with the ACM `acmart` class, then run:

```bash
latexmk -pdf -shell-escape -interaction=nonstopmode -halt-on-error main.tex
```

The included `main.bbl` preserves the generated bibliography. The BibTeX source
is available in `bibliography.bib`. Vector figures are in `figures/`; their
Python source and the result tables used for the statistical plot are included
for reproducibility.

See `RESULTS_PROVENANCE.md` for the evidence and reconstruction boundary.
